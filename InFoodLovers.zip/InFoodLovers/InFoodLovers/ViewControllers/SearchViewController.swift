//
//  SearchViewController.swift
//  InFoodLovers
//
//  Created by issd on 31/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth


class SearchViewController: UIViewController {
    //@IBOutlet weak var photo: UIImageView!
   
    @IBOutlet weak var tableView: UITableView!
    var searchBar = UISearchBar()
    
    var posts: [Post] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        searchBar.searchBarStyle = .minimal
        searchBar.placeholder = "Search"
        searchBar.frame.size.width = view.frame.size.width - 60
        
        let searchItem = UIBarButtonItem(customView: searchBar)
        self.navigationItem.rightBarButtonItem = searchItem
        
        loadPosts()
        doSearch()
        tableView.dataSource = self
        tableView.delegate = self
        //tableView.delegate = self as? UITableViewDelegate

        // Do any additional setup after loading the view.
    }
    
    func loadPosts() {
        guard let currentUser = Auth.auth().currentUser else {
            return
        }
        Api.Post.REF_POSTS.child(currentUser.uid).observe(.childAdded, with: {
            snapshot in
            Api.Post.observePost(withId: snapshot.key, completion: {
                posts in
                self.posts.append(posts)
                self.tableView.reloadData()
            })
        })
    }
 
    func doSearch() {
        if let searchText = searchBar.text?.lowercased() {
            self.posts.removeAll()
            self.tableView.reloadData()
            Api.Post.queryPosts(withText: searchText, completion: {(post) in
                self.posts.append(post)
                self.tableView.reloadData()
            })
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Discover_PostDetails" {
            let detailVC = segue.destination as! DetailViewController
            let postId = sender  as! String
            detailVC.postId = postId
        }
    }
}

extension SearchViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
       doSearch()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
       doSearch()
    }
}

extension SearchViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostsTableViewCell", for: indexPath) as! PostsTableViewCell
        let post = posts[indexPath.row]
        cell.post = post
        cell.delegate = self
        return cell
    }
}

extension SearchViewController: PostsTableViewCellDelegate {
    func goToDetailVC(postId : String) {
        performSegue(withIdentifier: "Discover_PostDetails", sender: postId)
    }

}
