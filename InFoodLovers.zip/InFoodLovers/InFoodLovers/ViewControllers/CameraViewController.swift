//
//  CameraViewController.swift
//  InFoodLovers
//
//  Created by issd on 18/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import UIKit
import Photos
import FirebaseStorage
import FirebaseDatabase
import FirebaseAuth
import AVFoundation

class CameraViewController: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate {
   
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var captionTextView: UITextView!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var removeButton: UIBarButtonItem!
    @IBOutlet weak var categoryTextField: UITextField!
    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    var selectedImage: UIImage?
    var videoUrl: URL?
    var currentTextField = UITextField()
    var pickerView = UIPickerView()
    var pickCategory = ["Breakfast","Lunch","Dinner","Dessert"]
    var hour:Int = 0
    var minute:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        shareButton.layer.cornerRadius = 5
        shareButton.clipsToBounds = true
        photo.layer.cornerRadius = 10
        photo.clipsToBounds = true
        captionTextView.layer.cornerRadius = 5
        captionTextView.clipsToBounds = true
        descriptionTextView.layer.cornerRadius = 5
        descriptionTextView.clipsToBounds = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleSelectPhoto))
        photo.addGestureRecognizer(tapGesture)
        photo.isUserInteractionEnabled = true

    }
    // Picker
   
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if currentTextField == categoryTextField{
            return 1
        }
        else if currentTextField == timeTextField {
            return 2
        }
        else {
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if currentTextField == categoryTextField{
            return pickCategory.count
        } else {
            switch component {
            case 0:
                return 25
            case 1,2:
                return 60
            default:
                return 0
            }
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        if currentTextField == categoryTextField {
            return pickerView.frame.size.width/1
        } else {
            return pickerView.frame.size.width/3
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if currentTextField == categoryTextField {
            return pickCategory[row]
        } else {
            switch component {
            case 0:
                return "\(row) Hours"
            case 1:
                return "\(row) Minutes"
            default:
                return ""
            }
            
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if currentTextField == categoryTextField {
            categoryTextField.text = pickCategory[row]
            self.view.endEditing(true)
        } else if currentTextField == timeTextField {
            switch component {
            case 0:
                hour = row
                timeTextField.text = String(hour) + "h " + ": " + String(minute) + "min"
            case 1:
                minute = row
                timeTextField.text = String(hour) + "h " + ": " + String(minute) + "min"
            default:
                break;
            }
        } else {
            " "
        }
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        currentTextField = textField
        if currentTextField == categoryTextField {
            currentTextField.inputView = pickerView
        } else if currentTextField == timeTextField {
            currentTextField.inputView = pickerView
        }
    }
    
   // end of Picker
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        handlePost()
    }
    
    func handlePost() {
        if selectedImage != nil {
            self.shareButton.isEnabled = true
            self.removeButton.isEnabled = true
            self.shareButton.backgroundColor = UIColor(red: 0, green: 84/255, blue: 140/255, alpha: 1)
        }else{
            self.shareButton.isEnabled = false
            self.removeButton.isEnabled = false
            self.shareButton.backgroundColor = .lightGray
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    @IBAction func cameraButton_TouchUpInside(_ sender: Any) {
        
    }
    
    @objc func handleSelectPhoto(){
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.mediaTypes = ["public.image","public.movie"]
        present(pickerController, animated: true, completion: nil)
    }
    

    @IBAction func shareButton_TouchUpInside(_ sender: Any) {
        view.endEditing(true)
        ProgressHUD.show("Waiting...", interaction: false)
        if let profileImg = self.selectedImage, let imageData = profileImg.jpegData(compressionQuality: 0.1){
            let ratio = profileImg.size.width / profileImg.size.height
            HelperService.uploadDataToServer(data: imageData, videoUrl: self.videoUrl, ratio: ratio, caption: captionTextView.text!,caption_lowercase :captionTextView.text!.lowercased(), description: descriptionTextView.text!,category: categoryTextField.text!, time: timeTextField.text!, onSuccess: {
                self.clean()
                self.tabBarController?.selectedIndex = 0
            })
    } else {
            ProgressHUD.showError("Profile Image can't be empty")
        }
    }
    @IBAction func remove_TouchUpInside(_ sender: Any) {
       clean()
       handlePost()
    }
    
    func clean() {
        self.captionTextView.text = ""
        self.photo.image = UIImage(named: "placeholder")
        self.selectedImage = nil
         self.categoryTextField.text = ""
         self.timeTextField.text = ""
         self.descriptionTextView.text = ""
    }
}
extension CameraViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        print("Did Finish Picking Media")
        print(info)
        
        if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
            if let thumnailImage = self.thumbnailImageForFileUrl(videoUrl) {
                selectedImage = thumnailImage
                photo.image = thumnailImage
                self.videoUrl = videoUrl
            }
        }
        if let image = info[.originalImage] as? UIImage{
            selectedImage = image
            photo.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
    func thumbnailImageForFileUrl(_ fileUrl: URL) -> UIImage? {
        let asset = AVAsset(url: fileUrl)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        imageGenerator.appliesPreferredTrackTransform = true
        
        do {
            let thumbnailCGImage = try imageGenerator.copyCGImage(at: CMTimeMake(value: 6, timescale: 3), actualTime: nil)
            return UIImage(cgImage: thumbnailCGImage)
        } catch let err {
            print(err)
        }
        
        return nil
    }

}
