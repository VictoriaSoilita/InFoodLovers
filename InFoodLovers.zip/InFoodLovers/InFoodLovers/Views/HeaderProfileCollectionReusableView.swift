//
//  HeaderProfileCollectionReusableView.swift
//  InFoodLovers
//
//  Created by issd on 24/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import UIKit
class HeaderProfileCollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    var user: UserModel? {
        didSet {
            updateView()
        }
    }
    
    func updateView() {
        self.nameLabel.text = user!.username
        if let photoUrlString = user!.profileImageUrl {
                let photoUrl = URL(string: photoUrlString)
                self.profileImage.sd_setImage(with: photoUrl)
            }
    }
}
