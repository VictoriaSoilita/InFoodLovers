//
//  PostsTableViewCell.swift
//  InFoodLovers
//
//  Created by issd on 31/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import UIKit

protocol PostsTableViewCellDelegate {
    func goToDetailVC(postId : String)
}

class PostsTableViewCell: UITableViewCell {
    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var captionLabel: UILabel!
    
    var delegate: PostsTableViewCellDelegate?
    
    var post: Post? {
        didSet {
            updateView()
        }
    }
    
    func updateView() {
        captionLabel.text = post?.caption
        timeLabel.text = post?.time
        if let photoUrlString = post?.photoUrl {
            let photoUrl = URL(string: photoUrlString)
            postImage.sd_setImage(with: photoUrl)
        }
        let tapGestureForPhoto = UITapGestureRecognizer(target: self, action: #selector(self.photo_TouchUpInside))
        postImage.addGestureRecognizer(tapGestureForPhoto)
        postImage.isUserInteractionEnabled = true
    }
   
    
    @objc func photo_TouchUpInside() {
        if let id = post?.id {
            delegate?.goToDetailVC(postId : id)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
