//
//  HomeTableViewCell.swift
//  InFoodLovers
//
//  Created by issd on 23/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseAuth
import ExpandableLabel
import AVFoundation
protocol HomeTableViewCellDelegate {
    func goToProfileUserVC(userId: String)
}

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var likeImageView: UIImageView!
    @IBOutlet weak var likeCountButton: UIButton!
    @IBOutlet weak var captionLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var dishNameLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var heightConstraintPhoto: NSLayoutConstraint!
    
    var delegate: HomeTableViewCellDelegate?
    var homeVC: HomeViewController?
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    var post: Post? {
        didSet {
            updateView()
        }
    }
    var user: UserModel? {
        didSet {
            setupUserInfo()
        }
    }
    // check this one if smth
    func updateView(){
        dishNameLabel.text = post?.caption
        captionLabel.text = post?.description
        timeLabel.text = post?.time
        categoryLabel.text = post?.category
        
        if let ratio = post?.ratio {
            heightConstraintPhoto.constant = UIScreen.main.bounds.width / ratio
            layoutIfNeeded()
        }
        if let photoUrlString = post?.photoUrl {
            let photoUrl = URL(string: photoUrlString)
            postImageView.sd_setImage(with: photoUrl)
        }
        if let videoUrlString = post?.videoUrl , let videoUrl = URL(string: videoUrlString){
            print("videoUrlString: \(videoUrlString)")
            
            player = AVPlayer(url: videoUrl)
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.frame = postImageView.frame
            playerLayer?.frame.size.width = UIScreen.main.bounds.width
            playerLayer?.frame.size.height = UIScreen.main.bounds.width/post!.ratio!
            self.contentView.layer.addSublayer(playerLayer!)
            player?.play()
        }
        self.updateLike(post: self.post!)
        
    }
    
    func updateLike(post: Post) {
        let imageName = post.likes == nil || !post.isLiked! ? "star" : "filled-star"
        likeImageView.image = UIImage(named: imageName)
        guard let count = post.likeCount else {
            return
        }
        if count != 0 {
            likeCountButton.setTitle("\(count) savings", for: UIControl.State.normal)
        } else {
            likeCountButton.setTitle("Be the first one who saves this", for: UIControl.State.normal)
        }
    }

    
    func setupUserInfo() {
        nameLabel.text = user?.username
        if let photoUrlString = user?.profileImageUrl {
            let photoUrl = URL(string: photoUrlString)
            profileImageView.sd_setImage(with: photoUrl, placeholderImage: UIImage(named: "avatar"))
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        nameLabel.text = ""
        captionLabel.text = ""
        
        let tapGestureForLikeImageView = UITapGestureRecognizer(target: self, action: #selector (self.likeImageView_TouchUpInside))
        likeImageView.addGestureRecognizer(tapGestureForLikeImageView)
        likeImageView.isUserInteractionEnabled = true
        
        let tapGestureForNameLabel = UITapGestureRecognizer(target: self, action: #selector(self.nameLabel_TouchUpInside))
        nameLabel.addGestureRecognizer(tapGestureForNameLabel)
        nameLabel.isUserInteractionEnabled = true
       
    }
    
    @objc func nameLabel_TouchUpInside() {
        if let id = user?.id {
            homeVC?.performSegue(withIdentifier: "ProfileSegue", sender: id)
            //delegate?.goToProfileUserVC(userId: id)
        }
    }
  
    
    @objc func likeImageView_TouchUpInside() {
        Api.Post.incrementLikes(postId: post!.id!, onSucess: { (post) in
            self.updateLike(post: post)
        }) { (errorMessage) in
            ProgressHUD.showError(errorMessage)
        }
    }
    
    
    override func prepareForReuse() {
        super.prepareForReuse()
        profileImageView.image = UIImage(named: "avatar")
        playerLayer?.removeFromSuperlayer()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

