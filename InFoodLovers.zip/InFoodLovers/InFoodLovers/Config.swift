//
//  Config.swift
//  InFoodLovers
//
//  Created by issd on 23/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import Foundation
struct Config {
    static var STORAGE_ROOT_REF = "gs://infoodlovers.appspot.com"
}
