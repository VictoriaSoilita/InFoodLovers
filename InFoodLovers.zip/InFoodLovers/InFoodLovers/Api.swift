//
//  Api.swift
//  InFoodLovers
//
//  Created by issd on 24/10/2018.
//  Copyright © 2018 Soilita Victoria. All rights reserved.
//

import Foundation

struct Api {
    static var User = UserApi()
    static var Post = PostApi()
    static var MyPosts =  MyPostsApi()
    static var Feed = FeedApi()
    
}
